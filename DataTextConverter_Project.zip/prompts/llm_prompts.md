
# LLM Prompts for Data & Text Converter

## Invoice Line Item Parser Prompt
Input: raw invoice text
Output: JSON list of line items with description, quantity, and price

## Social Media Caption Prompt
Input: raw text and target platform (Instagram, Twitter, LinkedIn)
Output: optimized caption text with appropriate tone and length

## JSON Validator Prompt
Input: raw JSON
Output: beautified JSON or error message

## Text-to-Table Prompt
Input: CSV or tab-separated text
Output: formatted markdown or HTML table
