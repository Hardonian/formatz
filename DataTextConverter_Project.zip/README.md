# Data & Text Converter Micro-App Project

This project is a combined micro-app integrating:
- Text-to-Table Converter
- JSON Validator & Formatter
- Invoice Line Item Parser
- Social Media Caption Format Converter

## Project Structure
- /api_spec: OpenAPI specification files
- /backend: Backend FastAPI scaffold and sample codes
- /frontend: Bolt UI JSON wireframes and suggested components
- /docs: Deployment & infrastructure guides
- /diagrams: Data flow and sequence diagrams
- /prompts: LLM prompt engineering templates
- /roadmap: Project roadmap and milestones

## How to Use
- Review individual folders for details
- Backend service is scaffolded in /backend
- Frontend wireframes designed for Bolt low-code in /frontend
- API spec defines endpoints for integration
- See README in each folder for specific instructions

## First Steps Post-Handover
1. Setup development environment and install dependencies
2. Review and finalize API spec and prompt templates
3. Begin backend and frontend incremental builds
4. Setup deployment environment as per docs
5. Iterate based on initial user feedback

