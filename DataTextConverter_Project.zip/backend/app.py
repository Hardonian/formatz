from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
import json

app = FastAPI(title="Data & Text Converter API")

# Models
class TextToTableRequest(BaseModel):
    inputText: str
    outputFormat: str

class JsonValidateRequest(BaseModel):
    inputJson: str

class InvoiceParseRequest(BaseModel):
    invoiceText: str

class CaptionConvertRequest(BaseModel):
    inputText: str
    platform: str

# Endpoints
@app.post("/convert/text-to-table")
async def text_to_table(req: TextToTableRequest):
    # Placeholder: convert text to markdown or html table
    if req.outputFormat not in ["markdown", "html"]:
        raise HTTPException(status_code=400, detail="Invalid outputFormat")
    formatted = f"Converted to {req.outputFormat}: {req.inputText[:50]}..."
    return {"formattedTable": formatted}

@app.post("/validate/json")
async def validate_json(req: JsonValidateRequest):
    try:
        parsed = json.loads(req.inputJson)
        formatted_json = json.dumps(parsed, indent=2)
        return {"formattedJson": formatted_json}
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON")

@app.post("/parse/invoice")
async def parse_invoice(req: InvoiceParseRequest):
    # Placeholder: simple mock
    return {
        "lineItems": [{"description": "Item A", "quantity": 1, "price": 10.0}],
        "total": 10.0,
        "date": "2025-10-08"
    }

@app.post("/convert/caption")
async def convert_caption(req: CaptionConvertRequest):
    # Placeholder: simple mock
    return {"caption": f"Caption for {req.platform}: {req.inputText[:50]}..."}

